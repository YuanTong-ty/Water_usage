rm(list = ls())
library(tidyverse)
library(sf)         # 用于空间数据
library(ggplot2)    # 绘图包
library(dplyr)      # 数据处理
library(readxl)     # 读取Excel文件
library(viridisLite)
library(viridis)

# 注意：根据你的实际文件路径修改以下路径
map_path <- "D:/自科水资源-数据&代码/历年中国省市区县地图（小地图版本+长版）/provmapdata/minishp/chinaprov2021mini/chinaprov2021mini.shp"
line_map_path <- "D:/自科水资源-数据&代码/历年中国省市区县地图（小地图版本+长版）/provmapdata/minishp/chinaprov2021mini/chinaprov2021mini_line.shp"
water_data_path <- "D:/自科水资源-数据&代码/ESR工企污染数据调整/ESR/用水量-27部门-ESR.xlsx"

# 设置CRS
mycrs <- "+proj=aea +lat_0=0 +lon_0=105 +lat_1=25 +lat_2=47 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs"

# 读取省级地图和线图
provmap <- read_sf(map_path) %>%
  filter(!is.na(省代码)) %>%
  mutate(省代码 = as.character(省代码))

provlinemap <- read_sf(line_map_path) %>%
  filter(class %in% c("九段线", "海岸线", "小地图框格")) %>%
  select(class)

# 假设你的数据框名为companies，包含企业所在的省Province和市City
company_count <- Green_id %>%
  group_by(市) %>%
  summarise(NumCompanies = n()) %>%
  ungroup()

# 合并企业数量数据与市级边界数据
merged_data <- city_boundaries %>%
  left_join(company_count, by = "City")

# 读取用水量数据
water_data <- read_excel(water_data_path, sheet = "各省部门汇总") %>%
  mutate(省代码 = as.character(省代码))

# 循环从2004年到2014年
for (year in 2004:2014) {
  # 筛选出当前年份的数据
  merged_data <- provmap %>%
    left_join(water_data %>% filter(Year == year), by = "省代码")
  
  # 绘制地图
  plot <- ggplot() +
    geom_sf(data = merged_data, aes(fill = NumCompanies), color = "white") +
    geom_sf(data = provlinemap, aes(color = "gray"), size = 0.3, show.legend = FALSE) +
    scale_fill_viridis_c(option = "viridis", direction = -1) +
    geom_sf_text(data = merged_data, aes(label = Province, color = ifelse(adjusted_water_new < 300, "black", "white")), nudge_y = -0.1, size = 1.9, fontface = "bold") +
    scale_color_identity() +
    labs(fill = "Number of enterprises", year) +
    theme_minimal()
  
  # 输出图像到文件
  ggsave(paste0("water_usage_map_", year, ".png"), plot, width = 10, height = 8)
}

