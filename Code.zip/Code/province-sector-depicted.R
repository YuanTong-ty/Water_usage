rm(list = ls())
# 导入必要的库
library(ggplot2)
library(dplyr)
library(readxl)

# 读取数据
file_path <- "C:/Users/童源/Desktop/用水量-27部门-ESR.xlsx"
all_years_sheets <- c("2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014")


# 循环处理每一年的数据
for (year_sheet in all_years_sheets) {
  # 读取全国各年用水情况数据
  national_data <- read_excel(file_path, sheet = "全国部门汇总")
  
  # 读取指定年份的省份数据
  province_data <- read_excel(file_path, sheet = year_sheet)
  
  # 对 "adjusted_water_new" 列取对数
  national_data$`adjusted_water_new` <- log(national_data$`adjusted_water_new`*10000)
  province_data$`adjusted_water_new` <- log(province_data$`adjusted_water_new`*10000)

  # 选取用水最多的5个省份
  top_provinces <- switch(year_sheet,
                          "2004" = c("Jiangsu", "Xinjiang", "Guangdong", "Hunan", "Guangxi"),
                          "2005" = c("Jiangsu", "Xinjiang", "Guangdong",  "Hunan", "Guangxi"),
                          "2006" = c("Jiangsu", "Xinjiang",  "Guangdong", "Hunan", "Guangxi"),
                          "2007" = c("Jiangsu", "Xinjiang",  "Guangdong", "Hunan", "Guangxi"),
                          "2008" = c("Jiangsu", "Xinjiang",  "Guangdong", "Hunan", "Guangxi"),
                          "2009" = c("Jiangsu", "Xinjiang",  "Guangdong", "Hunan", "Heilongjiang"),
                          "2010" = c("Jiangsu","Xinjiang",  "Guangdong", "Heilongjiang", "Hunan"),
                          "2011" = c("Jiangsu", "Xinjiang", "Guangdong", "Heilongjiang", "Hunan"),
                          "2012" = c("Xinjiang", "Jiangsu", "Guangdong", "Heilongjiang", "Hunan"),
                          "2013" = c("Xinjiang", "Jiangsu", "Heilongjiang", "Guangdong", "Hunan"),
                          "2014" = c("Jiangsu", "Xinjiang",  "Guangdong", "Heilongjiang", "Hunan")
  )
  
  # 提取相应年份的数据
  national_data_year <- national_data %>%
    filter(Year == as.numeric(year_sheet))
  
  province_data_top <- province_data %>%
    filter(Province %in% top_provinces)

  # 绘制全国各年用水情况图
  gg_national <- ggplot(data = national_data_year) +
    geom_bar(aes(x = as.factor(Sector), y = `adjusted_water_new`), stat = "identity") +
    labs(y = "Log adjusted_water_new", x = "Sector") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 0, hjust = 1),
          axis.title.y = element_text(size = 12),  # 设置 y 轴标题大小
          axis.title.x = element_text(size = 12),  # 设置 x 轴标题大小
          )  # 调整图形的边距
  
  # 设置 y 轴范围
  gg_national <- gg_national + ylim(0, max(national_data_year$`adjusted_water_new`) + 1)
  
  # 保存全国图表
  ggsave(filename = paste("全国水资源图表_", year_sheet, ".png", sep = ""), plot = gg_national, width = 12, height = 6)  # 调整图形的宽度和高度
  
  # 显示全国图表
  print(gg_national)
  
  # 绘制Top 5省份图表
  gg_province <- ggplot(data = province_data_top) +
    geom_bar(aes(x = as.factor(Sector), y = `adjusted_water_new`), stat = "identity") +
    labs(y = "Log Water Usage", x = "Sector") +
    facet_wrap(~ Province, scales = "free_y", ncol = 2) +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 0, hjust = 1),
          axis.title.y = element_text(size = 12),  # 设置 y 轴标题大小
          axis.title.x = element_text(size = 12),  # 设置 x 轴标题大小
          )  # 调整图形的边距
  
  # 设置 y 轴范围
  gg_province <- gg_province + ylim(0, max(province_data_top$`adjusted_water_new`) + 1)
  
  # 保存Top 5省份图表
  ggsave(filename = paste("Top5省份水资源图表_", year_sheet, ".png", sep = ""), plot = gg_province, width = 12, height = 6)  # 调整图形的宽度和高度
  
  # 将全国图和Top 5省份图放在一起
  # combined_plot <- grid.arrange(gg_national, gg_province, ncol = 2)
  
  # 保存合并图表
  #ggsave(filename = paste("合并图表_", year_sheet, ".png", sep = ""), plot = combined_plot, width = 20, height = 9)  # 调整图形的宽度和高度
  
  #print(combined_plot)
  
  # 显示Top 5省份图表
  print(gg_province)
}
