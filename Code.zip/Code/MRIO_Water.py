import pandas as pd
import numpy as np
from itertools import product
import matplotlib.pyplot as plt
plt.ion()
import seaborn as sns

# 1. 数据预处理(微观宏观占比）

# 读取Excel文件
file_path = r'D:\自科水资源-数据&代码\Collapse_0515.xlsx'
df = pd.read_excel(file_path, sheet_name='Sheet1')

# 确保'province'列是字符串类型
df['province'] = df['province'].astype(str)

# 更新water_new列的值
df['water_new'] = df['water_new'] / 10000

# 设置province的顺序
province_order = ['北京市', '天津市', '河北省', '山西省', '内蒙古自治区', '辽宁省', '吉林省', '黑龙江省', '上海市', '江苏省',
                   '浙江省', '安徽省', '福建省', '江西省', '山东省', '河南省', '湖北省', '湖南省', '广东省', '广西壮族自治区',
                   '海南省', '重庆市', '四川省', '贵州省', '云南省', '西藏自治区', '陕西省', '甘肃省', '青海省',
                   '宁夏回族自治区', '新疆维吾尔自治区']

# 将'province'列转换为Categorical类型，以确保排序
df['province'] = pd.Categorical(df['province'], categories=province_order, ordered=True)

# 按照年份和province排序，并重新索引
df_sorted = df.sort_values(by=['year', 'province']).reset_index(drop=True)

# 统计每个年份各province的water_new
result = df_sorted.groupby(['year', 'province'])[['water_new','wastewater_pf', 'COD_pf']].sum().reset_index()

# 输出
result.to_excel("D:\\自科水资源-数据&代码\\Year-Province-Water-ESR-0515.xlsx", index=False)


# 2. 省份部门调整
# 微观省份部门用水结果
file_path = r'D:\自科水资源-数据&代码\Collapse_0515.xlsx'
df = pd.read_excel(file_path)

# 更新water_new列的值
df['water_new'] = df['water_new'] / 10000

# 指定省份顺序
province_order = ['北京市', '天津市', '河北省', '山西省', '内蒙古自治区', '辽宁省', '吉林省', '黑龙江省', '上海市', '江苏省',
                   '浙江省', '安徽省', '福建省', '江西省', '山东省', '河南省', '湖北省', '湖南省', '广东省', '广西壮族自治区',
                   '海南省', '重庆市', '四川省', '贵州省', '云南省', '西藏自治区', '陕西省', '甘肃省', '青海省',
                   '宁夏回族自治区', '新疆维吾尔自治区']

# 中文省份到英文省份的映射字典
province_mapping = {
    '北京市': 'Beijing',
    '天津市': 'Tianjin',
    '河北省': 'Hebei',
    '山西省': 'Shanxi',
    '内蒙古自治区': 'Inner Mongolia',
    '辽宁省': 'Liaoning',
    '吉林省': 'Jilin',
    '黑龙江省': 'Heilongjiang',
    '上海市': 'Shanghai',
    '江苏省': 'Jiangsu',
    '浙江省': 'Zhejiang',
    '安徽省': 'Anhui',
    '福建省': 'Fujian',
    '江西省': 'Jiangxi',
    '山东省': 'Shandong',
    '河南省': 'Henan',
    '湖北省': 'Hubei',
    '湖南省': 'Hunan',
    '广东省': 'Guangdong',
    '广西壮族自治区': 'Guangxi',
    '海南省': 'Hainan',
    '重庆市': 'Chongqing',
    '四川省': 'Sichuan',
    '贵州省': 'Guizhou',
    '云南省': 'Yunnan',
    '西藏自治区': 'Tibet',
    '陕西省': 'Shaanxi',
    '甘肃省': 'Gansu',
    '青海省': 'Qinghai',
    '宁夏回族自治区': 'Ningxia',
    '新疆维吾尔自治区': 'Xinjiang'
}

# 提取指定列
df_extracted = df[['year', 'province', 'IO行业代码', 'water_new', "wastewater_pf", "COD_pf"]]

# 创建一个新的Excel文件
output_file_path = r'D:\自科水资源-数据&代码\提取并汇总数据-ESR-0515.xlsx'
with pd.ExcelWriter(output_file_path, engine='xlsxwriter') as writer:
    # 遍历每个年份
    for year in df['year'].unique():
        # 提取每年的数据
        df_year = df_extracted[df_extracted['year'] == year]

        # 按照指定的省份顺序和IO行业代码升序排列
        df_year_sorted = df_year[df_year['province'].isin(province_order)].sort_values(by=['province', 'IO行业代码'], ascending=[True, True])

        # 按照province和IO行业代码进行汇总
        df_year_grouped = df_year_sorted.groupby(['year', 'province', 'IO行业代码'])[['water_new', "wastewater_pf", "COD_pf"]].sum().reset_index()

        # 按照province顺序重新排序
        df_year_grouped['province'] = pd.Categorical(df_year_grouped['province'], categories=province_order, ordered=True)
        df_year_grouped = df_year_grouped.sort_values(by=['province', 'IO行业代码']).reset_index(drop=True)

        # 将province替换为英文名称
        df_year_grouped['province'] = df_year_grouped['province'].map(province_mapping)

        # 保存到一个sheet中
        df_year_grouped.to_excel(writer, sheet_name=str(year), index=False)

# 微观数据按照宏观比例调整
# 读取水资源数据的Excel文件
water_new_file_path = r'D:\自科水资源-数据&代码\提取并汇总数据-ESR-0515.xlsx'
df_water_new = pd.read_excel(water_new_file_path, sheet_name=None)

# 读取绘图中间数据的Excel文件
industry_data_file_path = r'D:\自科水资源-数据&代码\Code\Data\绘图中间数据.xlsx'
df_industry_data = pd.read_excel(industry_data_file_path, sheet_name=None)

# 创建一个 Excel writer 对象，用于保存多个sheet
output_adjusted_file_path = r'D:\自科水资源-数据&代码\调整后的水资源数据-ESR-0515.xlsx'
with pd.ExcelWriter(output_adjusted_file_path, engine='xlsxwriter') as writer:
    for year, df_water_new_year in df_water_new.items():
        current_year = int(year)

        if 2004 <= current_year <= 2014:

            df_water_new_year['Province'] = df_water_new_year['province']

            df_year_industry = df_industry_data[str(current_year)][['Province', '工业用水量', '污水排放量', '化学需氧量']]

            df_water_new_year_sum = df_water_new_year.groupby(['Province', 'IO行业代码'])[['water_new', 'wastewater_pf', 'COD_pf']].sum().reset_index()

            df_water_new_year_sum2 = df_water_new_year.groupby(['Province'])[['water_new', 'wastewater_pf', 'COD_pf']].sum().reset_index()

            df_combined = pd.merge(df_water_new_year_sum2, df_year_industry, on='Province', how='left')

            df_combined['Factor_1'] = df_combined['water_new'] / df_combined['工业用水量']
            df_combined['Factor_2'] = df_combined['wastewater_pf'] / df_combined['污水排放量']
            df_combined['Factor_3'] = df_combined['COD_pf'] / df_combined['化学需氧量']

            df_combined2 = df_combined.drop(columns=['工业用水量','污水排放量', '化学需氧量', 'water_new', 'wastewater_pf', 'COD_pf'])
            df_combined2 = pd.merge(df_water_new_year_sum, df_combined2, on='Province', how='left')
            df_combined2['adjusted_water_new'] = df_combined2['water_new'] / df_combined2['Factor_1']
            df_combined2['adjusted_wastewater_pf'] = df_combined2['wastewater_pf'] / df_combined2['Factor_2']
            df_combined2['adjusted_COD_pf'] = df_combined2['COD_pf'] / df_combined2['Factor_3']

            df_combined2[['Province', 'IO行业代码', 'water_new', 'wastewater_pf', 'COD_pf', 'adjusted_water_new',
                          'adjusted_wastewater_pf', 'adjusted_COD_pf', 'Factor_1', 'Factor_2', 'Factor_3']].assign(Year=current_year).to_excel(
                writer, sheet_name=str(current_year), index=False)


# 3. 省份行业绘图
# 构建卫星矩阵
# 读取已有的调整后的水资源数据的Excel文件
adjusted_file_path = r'D:\自科水资源-数据&代码\调整后的水资源数据-ESR-0515.xlsx'
df_adjusted = pd.read_excel(adjusted_file_path, sheet_name=None)

# 定义指定的省份顺序
specified_provinces = ['Beijing', 'Tianjin', 'Hebei', 'Shanxi', 'Inner Mongolia', 'Liaoning', 'Jilin', 'Heilongjiang',
                        'Shanghai', 'Jiangsu', 'Zhejiang', 'Anhui', 'Fujian', 'Jiangxi', 'Shandong', 'Henan', 'Hubei',
                        'Hunan', 'Guangdong', 'Guangxi', 'Hainan', 'Chongqing', 'Sichuan', 'Guizhou', 'Yunnan', 'Tibet',
                        'Shaanxi', 'Gansu', 'Qinghai', 'Ningxia', 'Xinjiang']

# 新建一个字典用于存储添加了缺失数据后的DataFrame
df_added_missing = {}

# 循环处理每年的数据
for year, df_year in df_adjusted.items():
    current_year = int(year)
    # 生成指定省份和IO行业代码的所有组合
    all_combinations = pd.DataFrame(list(product(specified_provinces, range(1, 43))), columns=['Province', 'IO行业代码'])

    # 通过笛卡尔积生成所有可能的省份和IO行业代码的组合
    all_combinations = all_combinations.merge(df_year, on=['Province', 'IO行业代码'], how='left')

    # 将缺失的water_new等数据设为0
    all_combinations[['water_new', 'wastewater_pf', 'COD_pf', 'adjusted_water_new',
                      'adjusted_wastewater_pf', 'adjusted_COD_pf', 'Factor_1',
                      'Factor_2', 'Factor_3']] = all_combinations[
        ['water_new', 'wastewater_pf', 'COD_pf', 'adjusted_water_new',
         'adjusted_wastewater_pf', 'adjusted_COD_pf', 'Factor_1',
         'Factor_2', 'Factor_3']].fillna(0)

    # 生成新的Province_sector列
    all_combinations['Province_Sector'] = all_combinations['Province'] + '_' + all_combinations['IO行业代码'].astype(str)

    # 使用Categorical类型排序，保持指定的顺序
    all_combinations['Province'] = pd.Categorical(all_combinations['Province'], categories=specified_provinces, ordered=True)
    all_combinations = all_combinations.sort_values(['Province', 'IO行业代码'])

    # 将生成的DataFrame存入字典
    if 1998 <= current_year <= 2003:
        df_added_missing[year] = all_combinations[['Province_Sector', 'water_new']]
    else:
        df_added_missing[year] = all_combinations[['Province_Sector', 'adjusted_water_new']]

# 将新生成的数据保存到新的Excel文件中
output_added_missing_file_path = r'D:\自科水资源-数据&代码\卫星矩阵-ESR-0515.xlsx'
with pd.ExcelWriter(output_added_missing_file_path, engine='xlsxwriter') as writer:
    for year, df_added_missing_year in df_added_missing.items():
        df_added_missing_year.to_excel(writer, sheet_name=str(year), index=False)

# 修改部门27-省份行业绘图
file_path = r'D:\自科水资源-数据&代码\卫星矩阵-ESR-0515.xlsx'
xls = pd.ExcelFile(file_path)

# 创建一个新的Excel文件
output_file_path = r'D:\自科水资源-数据&代码\调整后-用水量-省份行业绘图-ESR-0515.xlsx'
with pd.ExcelWriter(output_file_path, engine='xlsxwriter') as writer:
    # 遍历每个sheet
    for sheet_name in xls.sheet_names:
        # 读取数据
        df = pd.read_excel(xls, sheet_name)

        # 跳过2004-2014sheet中sector为27到42的行
        if sheet_name.isdigit() and int(sheet_name) in range(2004, 2015):
            df = df[~df['Province_Sector'].str.split('_').str[1].astype(int).between(28, 42)]

            # 将Province_Sector列分割成两列
            df[['Province', 'Sector']] = df['Province_Sector'].str.split('_', expand=True)

            # 将处理后的数据写入新的Excel文件，每个sheet对应一个年份
            df.to_excel(writer, sheet_name=sheet_name, index=False)

        else:
            # 对于其他年份的sheet，直接写入新的Excel文件
            df.to_excel(writer, sheet_name=sheet_name, index=False)

# 添加部门1和27
# 读取处理后的数据
macro_micro_data = pd.read_excel("D:\\自科水资源-数据&代码\\Code\\Data\\绘图中间数据.xlsx", sheet_name=["2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014"])
io_data = pd.read_excel("D:\\自科水资源-数据&代码\\调整后-用水量-省份行业绘图-ESR-0515.xlsx", sheet_name=["2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014"])

# 创建一个新的Excel文件
output_file_path = r'D:\自科水资源-数据&代码\调整后-用水量-省份部门绘图-ESR-0515.xlsx'
with pd.ExcelWriter(output_file_path, engine='xlsxwriter') as writer:
    for year in range(2004, 2015):
        io_sheet = io_data[str(year)]

        # 使用merge函数将两个表格按照Province进行合并
        merged_data = pd.merge(io_sheet, macro_micro_data[str(year)][["Province", "农业用水量", "建筑+服务业"]], on="Province", how="left")

        # 修改Sector为1的数据为农业用水量
        io_sheet.loc[io_sheet['Sector'] == 1, 'adjusted_water_new'] = merged_data.loc[io_sheet['Sector'] == 1, '农业用水量']

        # 修改Sector为27的数据为建筑+服务业
        io_sheet.loc[io_sheet['Sector'] == 27, 'adjusted_water_new'] = merged_data.loc[io_sheet['Sector'] == 27, '建筑+服务业']

        # 写入到新的Excel文件中，每个年份一个sheet
        io_sheet.to_excel(writer, sheet_name=str(year), index=False)


# 全国数据补充
# 读取调整后的省份部门绘图数据表
io_data = pd.read_excel("D:\\自科水资源-数据&代码\\调整后-用水量-省份部门绘图-ESR-0515.xlsx", sheet_name=["2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014"])

# 创建一个空的DataFrame用于存放每年全国各部门的用水量总和
national_total_df = pd.DataFrame()

# 遍历每个年份的数据
for year in range(2004, 2015):
    io_sheet = io_data[str(year)]

    # 按Sector对数据进行分组并计算各Sector的用水量总和
    total_sector_usage = io_sheet.groupby("Sector")["adjusted_water_new"].sum().reset_index()

    # 添加年份列
    total_sector_usage["Year"] = year

    # 将计算出的总和数据添加到总的DataFrame中
    national_total_df = pd.concat([national_total_df, total_sector_usage], ignore_index=True, sort=False)

# 创建一个空的DataFrame用于存放每年各省的用水量总和
province_total_df = pd.DataFrame()

# 遍历每个年份的数据
for year in range(2004, 2015):
    io_sheet = io_data[str(year)]

    # 按Province对数据进行分组并计算各Province的用水量总和
    total_province_usage = io_sheet.groupby("Province")["adjusted_water_new"].sum().reset_index()

    # 添加年份列
    total_province_usage["Year"] = year

    # 将计算出的总和数据添加到总的DataFrame中
    province_total_df = pd.concat([province_total_df, total_province_usage], ignore_index=True, sort=False)

    # 按用水量从高到低排序
    province_total_df.sort_values(by=["Year", "adjusted_water_new"], ascending=[True, False], inplace=True)

# 保存总的用水量总和数据到Excel文件
province_total_df.to_excel("D:\\自科水资源-数据&代码\\各省用水量总和-ESR-0515.xlsx", index=False)
national_total_df.to_excel("D:\\自科水资源-数据&代码\\全国部门用水量总和-ESR-0515.xlsx", index=False)


# 4. MRIO计算
# IO表-用水量 文件路径
water_path = r'D:\自科水资源-数据&代码\卫星矩阵-ESR-0515.xlsx'
output_excel_path = r'D:\自科水资源-数据&代码\Water_Net_Matrix-0515.xlsx'

# 构建 MRIO 表文件路径字典
mrio_paths = {
    "1998": r'D:\自科水资源-数据&代码\调整绘图\IO表-1997.xlsx',
    "1999": r'D:\自科水资源-数据&代码\调整绘图\IO表-1997.xlsx',
    "2000": r'D:\自科水资源-数据&代码\调整绘图\IO表-2002.xlsx',
    "2001": r'D:\自科水资源-数据&代码\调整绘图\IO表-2002.xlsx',
    "2002": r'D:\自科水资源-数据&代码\调整绘图\IO表-2002.xlsx',
    "2003": r'D:\自科水资源-数据&代码\调整绘图\IO表-2002.xlsx',
    "2004": r'D:\自科水资源-数据&代码\调整绘图\IO表-2002.xlsx',
    "2005": r'D:\自科水资源-数据&代码\调整绘图\IO表-2007.xlsx',
    "2006": r'D:\自科水资源-数据&代码\调整绘图\IO表-2007.xlsx',
    "2007": r'D:\自科水资源-数据&代码\调整绘图\IO表-2007.xlsx',
    "2008": r'D:\自科水资源-数据&代码\调整绘图\IO表-2007.xlsx',
    "2009": r'D:\自科水资源-数据&代码\调整绘图\IO表-2007.xlsx',
    "2010": r'D:\自科水资源-数据&代码\调整绘图\IO表-2012.xlsx',
    "2011": r'D:\自科水资源-数据&代码\调整绘图\IO表-2012.xlsx',
    "2012": r'D:\自科水资源-数据&代码\调整绘图\IO表-2012.xlsx',
    "2013": r'D:\自科水资源-数据&代码\调整绘图\IO表-2012.xlsx',
    "2014": r'D:\自科水资源-数据&代码\调整绘图\IO表-2012.xlsx',
}

# 生成年份列表
years = ["1998", "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014"]

with pd.ExcelWriter(output_excel_path, engine='xlsxwriter') as writer:
    for year in years:
        # 读取 IO 表-用水量 数据
        water_data = pd.read_excel(water_path, sheet_name=year, index_col=0)

        # 读取对应年份的 MRIO 表数据
        mrio_path = mrio_paths[year]
        input_output_data = pd.read_excel(mrio_path, sheet_name="MRIO_processed", index_col=0)

        # 将DataFrame数据转换为NumPy数组
        input_output_array = input_output_data.values  # 1351*1461
        water_array = water_data.values

        # 找到全为0的行和列的索引
        zero_rows = np.where(np.all(input_output_array == 0, axis=1))[0]
        zero_columns = np.where(np.all(input_output_array == 0, axis=0))[0]

        # 将全为0的行的数据改为0.00001
        input_output_array[zero_rows, :] = 0.00001

        # 将全为0的列的数据改为0.00001
        input_output_array[:, zero_columns] = 0.00001

        # 获取省份和部门的数量
        num_provinces = 31
        num_sectors = 42

        # 提取水资源消费数据中与部门数相匹配的列
        water_consumption = water_array[:num_provinces * num_sectors, :num_sectors]

        # 各类矩阵计算
        x_matrix = input_output_array[:num_provinces * num_sectors, :num_provinces * num_sectors]
        X_matrix = input_output_array[-1:, :num_provinces * num_sectors]
        # 将X_matrix中的零元素替换为一个很小的非零值
        X_matrix[X_matrix == 0] = np.finfo(float).eps
        Y_matrix = input_output_array[:num_provinces * num_sectors, num_provinces * num_sectors:-3]
        A_matrix = np.divide(x_matrix, X_matrix)
        I_matrix = np.eye(num_provinces * num_sectors)
        # Leontief逆矩阵
        Leontief = np.linalg.inv(I_matrix - A_matrix)
        # 直接水资源消耗强度矩阵
        Water_matrix = (np.diag(np.squeeze(water_consumption))) / (np.diag(X_matrix))
        # 水资源消耗矩阵
        C_Water_matrix = Water_matrix @ Leontief @ Y_matrix

        # 区域最终消费合并
        C_Water_matrix_consumption_merge = np.zeros((1302, 31))
        for i in range(31):
            C_Water_matrix_consumption_merge[:, i] = np.sum(C_Water_matrix[:, i * 3:(i * 3 + 3)], axis=1)

        # 部门分解的消费驱动量矩阵
        C_Water_matrix_apartment_merge = np.zeros((42, 31))
        for i in range(42):
            C_Water_matrix_apartment_merge[i] = np.sum(C_Water_matrix_consumption_merge[i * 31:(i * 31 + 31)], axis=0)

        # 区域间虚拟水资源交易情况
        # 各部门水资源消耗量相加：区域-区域消费驱动量矩阵
        C_Water_matrix_coal_merge = np.zeros((31, 31))
        for i in range(31):
            C_Water_matrix_coal_merge[i] = np.sum(C_Water_matrix_consumption_merge[i * 42:(i * 42 + 42)], axis=0)
        # 区域间水资源净转移量
        C_Water_Net_matrix = C_Water_matrix_coal_merge - np.transpose(C_Water_matrix_coal_merge)

        # 将矩阵转换为 pandas 的 DataFrame
        df = pd.DataFrame(C_Water_Net_matrix)
        df1 = pd.DataFrame(C_Water_matrix_consumption_merge)
        df2 = pd.DataFrame(C_Water_matrix)

        df.to_excel(writer, sheet_name=f'{year}', index=range(0, 31), columns=range(0, 31))


# 部门间虚拟水资源交易情况
    C_Water_matrix_consumption_merge_sector = np.zeros((1302, 42))
    for i in range(42):
        C_Water_matrix_consumption_merge_sector[:, i] = np.sum(C_Water_matrix[:, i * 31:(i * 31 + 31)], axis=1)

    # 部门分解的消费驱动量矩阵
    C_Water_matrix_apartment_merge_sector = np.zeros((42, 42))
    for i in range(42):
        C_Water_matrix_apartment_merge_sector[i] = np.sum(C_Water_matrix_consumption_merge_sector[i * 31:(i * 31 + 31)], axis=0)

    # 各区域水资源消耗量相加：部门-部门消费驱动量矩阵
    C_Water_matrix_coal_merge_sector = np.zeros((42, 42))
    for i in range(42):
        C_Water_matrix_coal_merge_sector[i] = np.sum(C_Water_matrix_consumption_merge_sector[i * 31:(i * 31 + 31)], axis=0)
    # 区域间水资源净转移量
    C_Water_Net_matrix_sector = C_Water_matrix_coal_merge_sector - np.transpose(C_Water_matrix_coal_merge_sector)

    # 将矩阵转换为 pandas 的 DataFrame
    df_sector = pd.DataFrame(C_Water_Net_matrix_sector)

    # 输出各年的结果到 Excel 文件
    df_sector.to_excel(writer, sheet_name=f'Water_matrix_sector_{year}', index=range(0, 42),
                       columns=range(0, 42))

# 统计缺失
# 读取已有的调整后的水资源数据的Excel文件
adjusted_file_path = r'D:\自科水资源-数据&代码\调整后的水资源数据.xlsx'
df_adjusted = pd.read_excel(adjusted_file_path, sheet_name=None)

df_missing_provinces = {}
specified_provinces = ['Beijing', 'Tianjin', 'Hebei', 'Shanxi', 'InnerMongolia', 'Liaoning', 'Jilin',
                        'Heilongjiang', 'Shanghai', 'Jiangsu', 'Zhejiang', 'Anhui', 'Fujian', 'Jiangxi',
                        'Shandong', 'Henan', 'Hubei', 'Hunan', 'Guangdong', 'Guangxi', 'Hainan', 'Chongqing',
                        'Sichuan', 'Guizhou', 'Yunnan', 'Tibet', 'Shanaxi', 'Gansu', 'Qinghai', 'Ningxia', 'Xinjiang']

for year, df_year in df_adjusted.items():
    # 检查缺失值
    missing_provinces = set(specified_provinces) - set(df_year['Province'].unique())

    # 创建包含缺失省份的DataFrame
    df_missing_provinces[year] = pd.DataFrame({'Missing_Province': list(missing_provinces)})

# 将缺失省份的数据保存到新的Excel文件中
output_missing_provinces_file_path = r'D:\自科水资源-数据&代码\缺失省份统计.xlsx'
with pd.ExcelWriter(output_missing_provinces_file_path, engine='xlsxwriter') as writer:
    for year, df_missing_provinces_year in df_missing_provinces.items():
        df_missing_provinces_year.to_excel(writer, sheet_name=str(year), index=False)

# 宏微观占比图
# 载入Excel文件
file_path = 'D:/自科水资源-数据&代码/调整后的水资源数据-ESR-0515.xlsx'
xl = pd.ExcelFile(file_path)

# 定义省份顺序，包括西藏
province_order = [
    'Beijing', 'Tianjin', 'Hebei', 'Shanxi', 'Inner Mongolia',
    'Liaoning', 'Jilin', 'Heilongjiang', 'Shanghai', 'Jiangsu',
    'Zhejiang', 'Anhui', 'Fujian', 'Jiangxi', 'Shandong',
    'Henan', 'Hubei', 'Hunan', 'Guangdong', 'Guangxi',
    'Hainan', 'Chongqing', 'Sichuan', 'Guizhou', 'Yunnan','Tibet',
    'Shaanxi', 'Gansu', 'Qinghai', 'Ningxia', 'Xinjiang'
     # 添加西藏
]

# 初始化一个空的DataFrame来存储所有年份的数据
df_all_years = pd.DataFrame()

# 循环提取2004到2014年的数据，包括省份和Factor_1
for year in range(2004, 2015):
    df_year = xl.parse(str(year))[['Province', 'Factor_1']].drop_duplicates()
    df_year['Year'] = year  # 添加年份列
    df_all_years = pd.concat([df_all_years, df_year])

# 确保DataFrame按照指定的省份顺序排序
df_all_years['Province'] = pd.Categorical(df_all_years['Province'], categories=province_order, ordered=True)
df_all_years = df_all_years.sort_values(['Year', 'Province'])

# 将DataFrame转换为年份为列，省份为行的形式
df_pivot = df_all_years.pivot(index='Province', columns='Year', values='Factor_1')

# 绘制热图
plt.figure(figsize=(12, 10))
sns.heatmap(df_pivot, annot=True, cmap='coolwarm', fmt=".2f")
plt.ylabel('Province')
plt.xlabel('Year')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
